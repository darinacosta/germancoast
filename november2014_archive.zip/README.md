vignettes_bootstrap
===================
